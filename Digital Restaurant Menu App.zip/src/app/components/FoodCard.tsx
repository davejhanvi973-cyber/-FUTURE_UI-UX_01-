import { Plus, Check } from 'lucide-react';
import { useState } from 'react';

interface FoodCardProps {
  item: {
    id: string;
    name: string;
    price: number;
    description?: string;
    image: string;
    category: string;
  };
  onAddToCart: (item: any) => void;
}

export function FoodCard({ item, onAddToCart }: FoodCardProps) {
  const [added, setAdded] = useState(false);

  const handleAddToCart = () => {
    onAddToCart(item);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <img
        src={item.image}
        alt={item.name}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h3 className="text-xl font-semibold mb-2">{item.name}</h3>
        {item.description && (
          <p className="text-gray-600 text-sm mb-3 line-clamp-2">{item.description}</p>
        )}
        <div className="flex justify-between items-center">
          <span className="text-2xl font-bold text-red-600">₹{item.price.toFixed(2)}</span>
          <button
            onClick={handleAddToCart}
            disabled={added}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors font-semibold ${
              added
                ? 'bg-green-500 text-white'
                : 'bg-red-600 hover:bg-red-700 text-white'
            }`}
          >
            {added ? (
              <>
                <Check className="w-5 h-5" />
                Added
              </>
            ) : (
              <>
                <Plus className="w-5 h-5" />
                Add
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}