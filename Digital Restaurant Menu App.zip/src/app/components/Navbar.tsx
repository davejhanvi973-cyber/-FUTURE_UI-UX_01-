import { ShoppingCart, User, LogOut, Home, UtensilsCrossed } from 'lucide-react';
import { useEffect, useState } from 'react';

interface NavbarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export function Navbar({ currentPage, onNavigate }: NavbarProps) {
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [cartCount, setCartCount] = useState(0);

  useEffect(() => {
    const user = localStorage.getItem('currentUser');
    const admin = localStorage.getItem('currentAdmin');
    if (user) {
      setCurrentUser(JSON.parse(user));
    }
    if (admin) {
      setIsAdmin(true);
    }
    updateCartCount();
  }, [currentPage]);

  const updateCartCount = () => {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const count = cart.reduce((sum: number, item: any) => sum + item.quantity, 0);
    setCartCount(count);
  };

  const handleLogout = () => {
    if (isAdmin) {
      localStorage.removeItem('currentAdmin');
      setIsAdmin(false);
    } else {
      localStorage.removeItem('currentUser');
      setCurrentUser(null);
    }
    onNavigate('home');
  };

  if (isAdmin) {
    return (
      <nav className="bg-red-600 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => onNavigate('admin')}>
              <UtensilsCrossed className="w-8 h-8" />
              <span className="text-xl font-bold">Admin Panel</span>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-4 py-2 bg-red-700 hover:bg-red-800 rounded-lg transition-colors"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </button>
          </div>
        </div>
      </nav>
    );
  }

  return (
    <nav className="bg-red-600 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => onNavigate('home')}>
            <UtensilsCrossed className="w-8 h-8" />
            <span className="text-xl font-bold">Delicious Bites</span>
          </div>
          
          <div className="flex items-center gap-4">
            <button
              onClick={() => onNavigate('home')}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-colors ${
                currentPage === 'home' ? 'bg-red-700' : 'hover:bg-red-700'
              }`}
            >
              <Home className="w-5 h-5" />
              <span className="hidden sm:inline">Home</span>
            </button>

            {currentUser && (
              <>
                <button
                  onClick={() => onNavigate('menu')}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-colors ${
                    currentPage === 'menu' ? 'bg-red-700' : 'hover:bg-red-700'
                  }`}
                >
                  <UtensilsCrossed className="w-5 h-5" />
                  <span className="hidden sm:inline">Menu</span>
                </button>

                <button
                  onClick={() => onNavigate('cart')}
                  className={`relative flex items-center gap-2 px-3 py-2 rounded-lg transition-colors ${
                    currentPage === 'cart' ? 'bg-red-700' : 'hover:bg-red-700'
                  }`}
                >
                  <ShoppingCart className="w-5 h-5" />
                  {cartCount > 0 && (
                    <span className="absolute -top-1 -right-1 bg-yellow-400 text-red-600 text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                      {cartCount}
                    </span>
                  )}
                  <span className="hidden sm:inline">Cart</span>
                </button>

                <button
                  onClick={handleLogout}
                  className="flex items-center gap-2 px-3 py-2 hover:bg-red-700 rounded-lg transition-colors"
                >
                  <LogOut className="w-5 h-5" />
                  <span className="hidden sm:inline">Logout</span>
                </button>
              </>
            )}

            {!currentUser && (
              <button
                onClick={() => onNavigate('login')}
                className="flex items-center gap-2 px-4 py-2 bg-white text-red-600 hover:bg-gray-100 rounded-lg transition-colors font-semibold"
              >
                <User className="w-5 h-5" />
                Login
              </button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
