import { useEffect, useState } from 'react';
import { Navbar } from './components/Navbar';
import { HomePage } from './pages/HomePage';
import { LoginPage } from './pages/LoginPage';
import { SignupPage } from './pages/SignupPage';
import { MenuPage } from './pages/MenuPage';
import { CartPage } from './pages/CartPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { OrderConfirmationPage } from './pages/OrderConfirmationPage';
import { AdminLoginPage } from './pages/AdminLoginPage';
import { AdminDashboardPage } from './pages/AdminDashboardPage';
import { initializeDefaultData } from './utils/localStorage';

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [orderData, setOrderData] = useState<any>(null);

  useEffect(() => {
    // Initialize default data on first load
    initializeDefaultData();

    // Check URL hash for navigation
    const hash = window.location.hash.slice(1);
    if (hash) {
      setCurrentPage(hash);
    }
  }, []);

  const navigate = (page: string) => {
    setCurrentPage(page);
    window.location.hash = page;
  };

  const handleOrderPlaced = (order: any) => {
    setOrderData(order);
    navigate('order-confirmation');
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'login':
        return <LoginPage onNavigate={navigate} />;
      case 'signup':
        return <SignupPage onNavigate={navigate} />;
      case 'menu':
        return <MenuPage onNavigate={navigate} />;
      case 'cart':
        return <CartPage onNavigate={navigate} />;
      case 'checkout':
        return <CheckoutPage onNavigate={navigate} onOrderPlaced={handleOrderPlaced} />;
      case 'order-confirmation':
        return <OrderConfirmationPage orderData={orderData} onNavigate={navigate} />;
      case 'admin-login':
        return <AdminLoginPage onNavigate={navigate} />;
      case 'admin':
        return <AdminDashboardPage onNavigate={navigate} />;
      default:
        return <HomePage onNavigate={navigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar currentPage={currentPage} onNavigate={navigate} />
      {renderPage()}
    </div>
  );
}
