import type { MenuItem, User, Order, CartItem } from '../types';

// Import custom image
import strawberryMilkshakeImg from 'figma:asset/75fc8f88a9ca9d2e3b8ff96e55fbd686798267b2.png';

// Get menu items from localStorage
export const getMenuItems = (): MenuItem[] => {
  return JSON.parse(localStorage.getItem('menuItems') || '[]');
};

// User management
export const registerUser = (email: string, password: string, name: string) => {
  const users = JSON.parse(localStorage.getItem('users') || '[]');
  
  // Check if user already exists
  if (users.find((u: any) => u.email === email)) {
    return { success: false, message: 'Email already registered' };
  }

  const newUser = {
    id: Date.now().toString(),
    email,
    password, // In real app, this should be hashed
    name,
    createdAt: new Date().toISOString()
  };

  users.push(newUser);
  localStorage.setItem('users', JSON.stringify(users));
  return { success: true, message: 'Registration successful' };
};

export const loginUser = (email: string, password: string) => {
  const users = JSON.parse(localStorage.getItem('users') || '[]');
  const user = users.find((u: any) => u.email === email && u.password === password);

  if (user) {
    const { password, ...userWithoutPassword } = user;
    localStorage.setItem('currentUser', JSON.stringify(userWithoutPassword));
    return { success: true, user: userWithoutPassword };
  }

  return { success: false, message: 'Invalid email or password' };
};

export const loginAdmin = (username: string, password: string) => {
  if (username === 'admin' && password === 'admin123') {
    localStorage.setItem('currentAdmin', JSON.stringify({ username: 'admin' }));
    return { success: true };
  }
  return { success: false, message: 'Invalid admin credentials' };
};

export const getCurrentUser = () => {
  const user = localStorage.getItem('currentUser');
  return user ? JSON.parse(user) : null;
};

// Cart management
export const addToCart = (item: any) => {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  const existingItem = cart.find((i: any) => i.id === item.id);

  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    cart.push({ ...item, quantity: 1 });
  }

  localStorage.setItem('cart', JSON.stringify(cart));
};

export const updateCartItemQuantity = (itemId: string, quantity: number) => {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  const item = cart.find((i: any) => i.id === itemId);

  if (item) {
    if (quantity <= 0) {
      const updatedCart = cart.filter((i: any) => i.id !== itemId);
      localStorage.setItem('cart', JSON.stringify(updatedCart));
    } else {
      item.quantity = quantity;
      localStorage.setItem('cart', JSON.stringify(cart));
    }
  }
};

export const removeFromCart = (itemId: string) => {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  const updatedCart = cart.filter((i: any) => i.id !== itemId);
  localStorage.setItem('cart', JSON.stringify(updatedCart));
};

export const getCart = () => {
  return JSON.parse(localStorage.getItem('cart') || '[]');
};

export const clearCart = () => {
  localStorage.setItem('cart', JSON.stringify([]));
};

// Order management
export const createOrder = (orderData: any) => {
  const orders = JSON.parse(localStorage.getItem('orders') || '[]');
  const newOrder = {
    id: Date.now().toString(),
    ...orderData,
    createdAt: new Date().toISOString(),
    status: 'Pending'
  };

  orders.push(newOrder);
  localStorage.setItem('orders', JSON.stringify(orders));
  clearCart();
  return newOrder;
};

export const getOrders = () => {
  return JSON.parse(localStorage.getItem('orders') || '[]');
};

// Menu management
export const addMenuItem = (item: any) => {
  const menuItems = JSON.parse(localStorage.getItem('menuItems') || '[]');
  const newItem = {
    id: Date.now().toString(),
    ...item
  };
  menuItems.push(newItem);
  localStorage.setItem('menuItems', JSON.stringify(menuItems));
  return newItem;
};

export const deleteMenuItem = (itemId: string) => {
  const menuItems = JSON.parse(localStorage.getItem('menuItems') || '[]');
  const updatedItems = menuItems.filter((item: any) => item.id !== itemId);
  localStorage.setItem('menuItems', JSON.stringify(updatedItems));
};

// Initialize default menu items
export const initializeDefaultData = () => {
  // Initialize menu items if not exists
  if (!localStorage.getItem('menuItems')) {
    const defaultMenuItems = [
      // Starters
      {
        id: '1',
        name: 'Simple Salted Fries',
        category: 'Starters',
        price: 70,
        description: 'Crispy golden fries with a perfect salt seasoning',
        image: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=400&h=300&fit=crop'
      },
      {
        id: '2',
        name: 'Peri Peri Fries',
        category: 'Starters',
        price: 90,
        description: 'Spicy peri peri seasoned fries',
        image: 'https://images.unsplash.com/photo-1630431341973-02e1f662ec44?w=400&h=300&fit=crop'
      },
      {
        id: '3',
        name: 'Peri Peri with Cheese',
        category: 'Starters',
        price: 100,
        description: 'Peri peri fries loaded with melted cheese',
        image: 'https://images.unsplash.com/photo-1627662168781-1df8e3628f4d?w=400&h=300&fit=crop'
      },
      {
        id: '4',
        name: 'Tandoori Fries',
        category: 'Starters',
        price: 100,
        description: 'Fries with tangy tandoori seasoning',
        image: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=400&h=300&fit=crop'
      },
      {
        id: '5',
        name: 'Veg Supreme',
        category: 'Starters',
        price: 79,
        description: 'Cheese with dressing of onion, capsicum, tomato',
        image: 'https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?w=400&h=300&fit=crop'
      },
      {
        id: '6',
        name: 'Peri Prime',
        category: 'Starters',
        price: 89,
        description: 'Peri peri plus cheese with selected veggies',
        image: 'https://images.unsplash.com/photo-1627662168781-1df8e3628f4d?w=400&h=300&fit=crop'
      },
      {
        id: '7',
        name: 'Cheese Blast',
        category: 'Starters',
        price: 99,
        description: 'Cheese loaded on top, selected veggie with selected sauce',
        image: 'https://images.unsplash.com/photo-1619221882420-ce16c7b6e33f?w=400&h=300&fit=crop'
      },
      // Main Course - Pizza
      {
        id: '8',
        name: 'Margherita Pizza (Large)',
        category: 'Main Course',
        price: 199,
        description: 'Classic mozzarella cheese pizza',
        image: 'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=400&h=300&fit=crop'
      },
      {
        id: '9',
        name: 'Cheese Corn Pizza (Large)',
        category: 'Main Course',
        price: 219,
        description: 'Sweet corn with cheese',
        image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&h=300&fit=crop'
      },
      {
        id: '10',
        name: 'Mexican Delight Pizza (Large)',
        category: 'Main Course',
        price: 229,
        description: 'Sweet corn, capsicum, olives, tomato',
        image: 'https://images.unsplash.com/photo-1571997478779-2adcbbe9ab2f?w=400&h=300&fit=crop'
      },
      {
        id: '11',
        name: 'Bread Pizza Margherita',
        category: 'Main Course',
        price: 199,
        description: 'Mozzarella cheese on bread base',
        image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400&h=300&fit=crop'
      },
      {
        id: '12',
        name: 'Bread Pizza Cheese Corn',
        category: 'Main Course',
        price: 219,
        description: 'Corn and cheese on bread base',
        image: 'https://images.unsplash.com/photo-1458642849426-cfb724f15ef7?w=400&h=300&fit=crop'
      },
      {
        id: '13',
        name: 'Bread Pizza Mexican Delight',
        category: 'Main Course',
        price: 229,
        description: 'Sweet corn, capsicum, olives, tomato on bread base',
        image: 'https://images.unsplash.com/photo-1555072956-7758afb20e8f?w=400&h=300&fit=crop'
      },
      {
        id: '14',
        name: 'Chilli Spicy Bread Pizza',
        category: 'Main Course',
        price: 239,
        description: 'Onion, green chilli, capsicum, tomato',
        image: 'https://images.unsplash.com/photo-1595708684082-a173bb3a06c5?w=400&h=300&fit=crop'
      },
      {
        id: '15',
        name: 'Margherita Pizza (Regular)',
        category: 'Main Course',
        price: 149,
        description: 'Classic mozzarella cheese pizza',
        image: 'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=400&h=300&fit=crop'
      },
      {
        id: '16',
        name: 'Cheese Corn Pizza (Regular)',
        category: 'Main Course',
        price: 169,
        description: 'Corn and cheese',
        image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&h=300&fit=crop'
      },
      {
        id: '17',
        name: 'Vegie Special Pizza',
        category: 'Main Course',
        price: 179,
        description: 'Onion, capsicum, tomato',
        image: 'https://images.unsplash.com/photo-1576458088443-04a19d7a07bc?w=400&h=300&fit=crop'
      },
      {
        id: '18',
        name: 'Chilli Garlic Pizza',
        category: 'Main Course',
        price: 189,
        description: 'Garlic and green chilli',
        image: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?w=400&h=300&fit=crop'
      },
      // Pasta
      {
        id: '19',
        name: 'Red Sauce Pasta',
        category: 'Main Course',
        price: 100,
        description: 'Classic Italian red sauce pasta',
        image: 'https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=400&h=300&fit=crop'
      },
      {
        id: '20',
        name: 'Alfredo Pasta',
        category: 'Main Course',
        price: 110,
        description: 'Creamy white sauce pasta',
        image: 'https://images.unsplash.com/photo-1612874742237-6526221588e3?w=400&h=300&fit=crop'
      },
      {
        id: '21',
        name: 'Pink Sauce Pasta',
        category: 'Main Course',
        price: 110,
        description: 'Creamy pink sauce pasta',
        image: 'https://images.unsplash.com/photo-1611599539113-c86be1ee6471?w=400&h=300&fit=crop'
      },
      {
        id: '22',
        name: 'Cheese Pasta',
        category: 'Main Course',
        price: 130,
        description: 'Pasta loaded with cheese',
        image: 'https://images.unsplash.com/photo-1645112411341-6c4fd023714a?w=400&h=300&fit=crop'
      },
      // Burgers
      {
        id: '23',
        name: 'Aloo Tikki Burger',
        category: 'Main Course',
        price: 50,
        description: 'Classic potato patty burger',
        image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=300&fit=crop'
      },
      {
        id: '24',
        name: 'Cheese Aloo Tikki Burger',
        category: 'Main Course',
        price: 60,
        description: 'Aloo tikki burger with cheese',
        image: 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=400&h=300&fit=crop'
      },
      {
        id: '25',
        name: 'Veg Classic Burger',
        category: 'Main Course',
        price: 70,
        description: 'Classic vegetable burger',
        image: 'https://images.unsplash.com/photo-1520072959219-c595dc870360?w=400&h=300&fit=crop'
      },
      {
        id: '26',
        name: 'Paneer Tikka Burger',
        category: 'Main Course',
        price: 80,
        description: 'Grilled paneer tikka burger',
        image: 'https://images.unsplash.com/photo-1606755962773-d324e0a13086?w=400&h=300&fit=crop'
      },
      {
        id: '27',
        name: 'Veg Peri Peri Burger',
        category: 'Main Course',
        price: 80,
        description: 'Spicy peri peri vegetable burger',
        image: 'https://images.unsplash.com/photo-1550547660-d9450f859349?w=400&h=300&fit=crop'
      },
      // Club Sandwich
      {
        id: '28',
        name: '3 Layer Paneer Spices',
        category: 'Main Course',
        price: 150,
        description: 'Paneer, rich spices, selected veg, crunch of veg tikki with tandoori sauce',
        image: 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?w=400&h=300&fit=crop'
      },
      // Grill Sandwich
      {
        id: '29',
        name: 'Veg Cheese Grill',
        category: 'Main Course',
        price: 80,
        description: 'Grilled sandwich with vegetables and cheese',
        image: 'https://images.unsplash.com/photo-1509722747041-616f39b57569?w=400&h=300&fit=crop'
      },
      {
        id: '30',
        name: 'Chilli Cheese Grill',
        category: 'Main Course',
        price: 80,
        description: 'Spicy chilli and cheese grilled sandwich',
        image: 'https://images.unsplash.com/photo-1553909489-cd47e0907980?w=400&h=300&fit=crop'
      },
      {
        id: '31',
        name: 'Aloo Matar Grill',
        category: 'Main Course',
        price: 90,
        description: 'Potato and peas grilled sandwich',
        image: 'https://images.unsplash.com/photo-1619683719542-b9eab585a419?w=400&h=300&fit=crop'
      },
      {
        id: '32',
        name: 'Paneer Tikka Grill',
        category: 'Main Course',
        price: 100,
        description: 'Paneer tikka grilled sandwich',
        image: 'https://images.unsplash.com/photo-1606755456206-b25206cde27e?w=400&h=300&fit=crop'
      },
      {
        id: '33',
        name: 'Mexican Grill',
        category: 'Main Course',
        price: 110,
        description: 'Mexican style grilled sandwich',
        image: 'https://images.unsplash.com/photo-1592415499556-74fcf4967084?w=400&h=300&fit=crop'
      },
      {
        id: '34',
        name: 'Veg Toofani Grill',
        category: 'Main Course',
        price: 120,
        description: 'Special spicy grilled sandwich',
        image: 'https://images.unsplash.com/photo-1621852004158-f3bc188ace2d?w=400&h=300&fit=crop'
      },
      // Desserts - Sizzling
      {
        id: '35',
        name: 'Sizzling Star',
        category: 'Desserts',
        price: 99,
        description: 'Chocolate brownie served with vanilla ice cream',
        image: 'https://images.unsplash.com/photo-1624353365286-3f8d62daad51?w=400&h=300&fit=crop'
      },
      {
        id: '36',
        name: 'Sizzling Chocobar',
        category: 'Desserts',
        price: 119,
        description: 'Chocolate brownie served with choco bar',
        image: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=400&h=300&fit=crop'
      },
      {
        id: '37',
        name: 'Oreo Crunch',
        category: 'Desserts',
        price: 129,
        description: 'Chocolate brownie loaded with Oreo cookies and vanilla ice cream',
        image: 'https://images.unsplash.com/photo-1558326567-98ae2405596b?w=400&h=300&fit=crop'
      },
      {
        id: '38',
        name: 'Nutella Thunder',
        category: 'Desserts',
        price: 179,
        description: 'Chocolate brownie loaded with Nutella and vanilla ice cream and choco toppings',
        image: 'https://images.unsplash.com/photo-1607920591413-4ec007e70023?w=400&h=300&fit=crop'
      },
      {
        id: '39',
        name: 'Sizzling Boat',
        category: 'Desserts',
        price: 199,
        description: 'Chocolate brownie loaded with triple chocolate and choco balls and vanilla ice cream',
        image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&h=300&fit=crop'
      },
      // Mud Brownie
      {
        id: '40',
        name: 'Mud Brownie',
        category: 'Desserts',
        price: 99,
        description: 'Classic chocolate mud brownie',
        image: 'https://images.unsplash.com/photo-1607920591413-4ec007e70023?w=400&h=300&fit=crop'
      },
      {
        id: '41',
        name: 'Mud Brownie with Vanilla Ice Cream',
        category: 'Desserts',
        price: 119,
        description: 'Mud brownie served with vanilla ice cream',
        image: 'https://images.unsplash.com/photo-1515037893149-de7f840978e2?w=400&h=300&fit=crop'
      },
      // Fudge Brownie
      {
        id: '42',
        name: 'White Chocolate Fudge Brownie',
        category: 'Desserts',
        price: 149,
        description: 'Rich white chocolate fudge brownie',
        image: 'https://images.unsplash.com/photo-1606890737304-57a1ca8a5b62?w=400&h=300&fit=crop'
      },
      {
        id: '43',
        name: 'Dark Chocolate Fudge Brownie',
        category: 'Desserts',
        price: 149,
        description: 'Rich dark chocolate fudge brownie',
        image: 'https://images.unsplash.com/photo-1606312619070-d48b4cda2b36?w=400&h=300&fit=crop'
      },
      {
        id: '44',
        name: 'Triple Chocolate Fudge Brownie',
        category: 'Desserts',
        price: 149,
        description: 'Triple chocolate loaded fudge brownie',
        image: 'https://images.unsplash.com/photo-1606890737304-57a1ca8a5b62?w=400&h=300&fit=crop'
      },
      // Beverages - Milkshakes
      {
        id: '45',
        name: 'Chocolate Milkshake',
        category: 'Beverages',
        price: 80,
        description: 'Creamy chocolate milkshake (350 ML)',
        image: 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?w=400&h=300&fit=crop'
      },
      {
        id: '46',
        name: 'Mango Milkshake',
        category: 'Beverages',
        price: 80,
        description: 'Fresh mango milkshake (350 ML)',
        image: 'https://images.unsplash.com/photo-1623065422902-30a2d299bbe4?w=400&h=300&fit=crop'
      },
      {
        id: '47',
        name: 'Strawberry Milkshake',
        category: 'Beverages',
        price: 80,
        description: 'Fresh strawberry milkshake (350 ML)',
        image: strawberryMilkshakeImg
      },
      {
        id: '48',
        name: 'Pineapple Milkshake',
        category: 'Beverages',
        price: 80,
        description: 'Tropical pineapple milkshake (350 ML)',
        image: 'https://images.unsplash.com/photo-1600271886742-f049cd451bba?w=400&h=300&fit=crop'
      },
      {
        id: '49',
        name: 'Watermelon Milkshake',
        category: 'Beverages',
        price: 90,
        description: 'Refreshing watermelon milkshake (350 ML)',
        image: 'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=400&h=300&fit=crop'
      },
      {
        id: '50',
        name: 'Saffron Milkshake',
        category: 'Beverages',
        price: 100,
        description: 'Premium saffron milkshake (350 ML)',
        image: 'https://images.unsplash.com/photo-1623065422902-30a2d299bbe4?w=400&h=300&fit=crop'
      },
      // Hot Beverages
      {
        id: '51',
        name: 'Hot Coffee',
        category: 'Beverages',
        price: 50,
        description: 'Fresh hot coffee (200 ML)',
        image: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=400&h=300&fit=crop'
      },
      {
        id: '52',
        name: 'Hot Chocolate',
        category: 'Beverages',
        price: 50,
        description: 'Rich hot chocolate (200 ML)',
        image: 'https://images.unsplash.com/photo-1517487881594-2787fef5ebf7?w=400&h=300&fit=crop'
      },
      // Mojitos
      {
        id: '53',
        name: 'Mint Mojito',
        category: 'Beverages',
        price: 70,
        description: 'Refreshing mint mojito',
        image: 'https://images.unsplash.com/photo-1551538827-9c037cb4f32a?w=400&h=300&fit=crop'
      },
      {
        id: '54',
        name: 'Blue Curacao Mojito',
        category: 'Beverages',
        price: 70,
        description: 'Vibrant blue curacao mojito',
        image: 'https://images.unsplash.com/photo-1546171753-97d7676e4602?w=400&h=300&fit=crop'
      },
      {
        id: '55',
        name: 'Strawberry Mojito',
        category: 'Beverages',
        price: 80,
        description: 'Fresh strawberry mojito',
        image: 'https://images.unsplash.com/photo-1602667593707-7583f896245d?w=400&h=300&fit=crop'
      },
      {
        id: '56',
        name: 'Watermelon Mojito',
        category: 'Beverages',
        price: 80,
        description: 'Refreshing watermelon mojito',
        image: 'https://images.unsplash.com/photo-1587223962930-cb7f31384c19?w=400&h=300&fit=crop'
      },
      {
        id: '57',
        name: 'Kiwi Mojito',
        category: 'Beverages',
        price: 80,
        description: 'Tangy kiwi mojito',
        image: 'https://images.unsplash.com/photo-1553530666-6d1f8da4a2c8?w=400&h=300&fit=crop'
      },
      {
        id: '58',
        name: 'Chilli Guava Mojito',
        category: 'Beverages',
        price: 90,
        description: 'Spicy chilli guava mojito',
        image: 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=400&h=300&fit=crop'
      },
      {
        id: '59',
        name: 'Spicy Mango Mojito',
        category: 'Beverages',
        price: 90,
        description: 'Tangy spicy mango mojito',
        image: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=400&h=300&fit=crop'
      }
    ];
    localStorage.setItem('menuItems', JSON.stringify(defaultMenuItems));
  }

  // Initialize empty arrays if not exists
  if (!localStorage.getItem('users')) {
    localStorage.setItem('users', JSON.stringify([]));
  }
  if (!localStorage.getItem('orders')) {
    localStorage.setItem('orders', JSON.stringify([]));
  }
  if (!localStorage.getItem('cart')) {
    localStorage.setItem('cart', JSON.stringify([]));
  }
};