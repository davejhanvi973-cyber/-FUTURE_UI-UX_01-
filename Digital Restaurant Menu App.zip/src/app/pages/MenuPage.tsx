import { useEffect, useState } from 'react';
import { FoodCard } from '../components/FoodCard';
import { getMenuItems, addToCart, getCurrentUser } from '../utils/localStorage';
import { UtensilsCrossed } from 'lucide-react';

interface MenuPageProps {
  onNavigate: (page: string) => void;
}

const categories = ['All', 'Starters', 'Main Course', 'Desserts', 'Beverages'];

export function MenuPage({ onNavigate }: MenuPageProps) {
  const [menuItems, setMenuItems] = useState<any[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [currentUser, setCurrentUser] = useState<any>(null);

  useEffect(() => {
    const user = getCurrentUser();
    if (!user) {
      onNavigate('login');
      return;
    }
    setCurrentUser(user);
    loadMenuItems();
  }, []);

  const loadMenuItems = () => {
    const items = getMenuItems();
    setMenuItems(items);
  };

  const filteredItems = selectedCategory === 'All'
    ? menuItems
    : menuItems.filter(item => item.category === selectedCategory);

  const handleAddToCart = (item: any) => {
    addToCart(item);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-12">
      {/* Header */}
      <div className="bg-red-600 text-white py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-center gap-3 mb-4">
            <UtensilsCrossed className="w-12 h-12" />
            <h1 className="text-4xl font-bold">Our Menu</h1>
          </div>
          <p className="text-center text-lg">Discover our delicious selection of dishes</p>
        </div>
      </div>

      {/* Category Filter */}
      <div className="bg-white shadow-md sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex gap-2 overflow-x-auto pb-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-6 py-2 rounded-full font-semibold whitespace-nowrap transition-colors ${
                  selectedCategory === category
                    ? 'bg-red-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Menu Items */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {filteredItems.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-600 text-lg">No items found in this category</p>
          </div>
        ) : (
          <>
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-900">
                {selectedCategory === 'All' ? 'All Items' : selectedCategory}
              </h2>
              <p className="text-gray-600">{filteredItems.length} items available</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredItems.map((item) => (
                <FoodCard key={item.id} item={item} onAddToCart={handleAddToCart} />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
