import { UtensilsCrossed, Clock, Award, Heart } from 'lucide-react';

interface HomePageProps {
  onNavigate: (page: string) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div 
        className="relative bg-cover bg-center h-[500px] flex items-center justify-center"
        style={{
          backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=1200&h=600&fit=crop)',
        }}
      >
        <div className="text-center text-white px-4">
          <div className="flex items-center justify-center mb-6">
            <UtensilsCrossed className="w-16 h-16" />
          </div>
          <h1 className="text-5xl md:text-6xl font-bold mb-4">Delicious Bites</h1>
          <p className="text-xl md:text-2xl mb-8">Experience the finest culinary delights</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => onNavigate('menu')}
              className="px-8 py-3 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-lg transition-colors text-lg"
            >
              View Menu
            </button>
            <button
              onClick={() => onNavigate('menu')}
              className="px-8 py-3 bg-white hover:bg-gray-100 text-red-600 font-semibold rounded-lg transition-colors text-lg"
            >
              Order Now
            </button>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">Why Choose Us</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center p-6 bg-white rounded-lg shadow-md">
            <div className="flex justify-center mb-4">
              <Clock className="w-12 h-12 text-red-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Fast Delivery</h3>
            <p className="text-gray-600">Quick and efficient service to get your food fresh and hot</p>
          </div>
          
          <div className="text-center p-6 bg-white rounded-lg shadow-md">
            <div className="flex justify-center mb-4">
              <Award className="w-12 h-12 text-red-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Quality Food</h3>
            <p className="text-gray-600">Made with the finest ingredients and authentic recipes</p>
          </div>
          
          <div className="text-center p-6 bg-white rounded-lg shadow-md">
            <div className="flex justify-center mb-4">
              <Heart className="w-12 h-12 text-red-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Made with Love</h3>
            <p className="text-gray-600">Every dish is prepared with passion and care</p>
          </div>
        </div>
      </div>

      {/* Featured Dishes */}
      <div className="bg-gray-100 py-16">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Featured Dishes</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg overflow-hidden shadow-md">
              <img
                src="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=300&fit=crop"
                alt="Burger"
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="text-xl font-semibold mb-2">Gourmet Burgers</h3>
                <p className="text-gray-600">Juicy, delicious burgers made to perfection</p>
              </div>
            </div>

            <div className="bg-white rounded-lg overflow-hidden shadow-md">
              <img
                src="https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=400&h=300&fit=crop"
                alt="Pizza"
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="text-xl font-semibold mb-2">Wood-Fired Pizza</h3>
                <p className="text-gray-600">Authentic Italian pizza with fresh toppings</p>
              </div>
            </div>

            <div className="bg-white rounded-lg overflow-hidden shadow-md">
              <img
                src="https://images.unsplash.com/photo-1624353365286-3f8d62daad51?w=400&h=300&fit=crop"
                alt="Desserts"
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="text-xl font-semibold mb-2">Decadent Desserts</h3>
                <p className="text-gray-600">Sweet treats to end your meal perfectly</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Call to Action */}
      <div className="bg-red-600 text-white py-16">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="text-3xl font-bold mb-4">Ready to Order?</h2>
          <p className="text-xl mb-8">Join us today and enjoy delicious meals delivered to your door</p>
          <button
            onClick={() => onNavigate('login')}
            className="px-8 py-3 bg-white text-red-600 hover:bg-gray-100 font-semibold rounded-lg transition-colors text-lg"
          >
            Get Started
          </button>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p>&copy; 2026 Delicious Bites. All rights reserved.</p>
          <div className="mt-4 flex justify-center gap-6">
            <a href="#admin-login" onClick={(e) => { e.preventDefault(); onNavigate('admin-login'); }} className="hover:text-red-400 transition-colors">
              Admin Login
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
