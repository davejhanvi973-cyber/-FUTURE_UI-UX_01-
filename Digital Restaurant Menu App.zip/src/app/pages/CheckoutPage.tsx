import { useEffect, useState } from 'react';
import { CreditCard, Smartphone, DollarSign, Store, ShoppingBag } from 'lucide-react';
import { getCart, getCurrentUser, createOrder } from '../utils/localStorage';

interface CheckoutPageProps {
  onNavigate: (page: string) => void;
  onOrderPlaced: (order: any) => void;
}

export function CheckoutPage({ onNavigate, onOrderPlaced }: CheckoutPageProps) {
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [cartItems, setCartItems] = useState<any[]>([]);
  const [customerName, setCustomerName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [orderType, setOrderType] = useState<'Dine-In' | 'Takeaway'>('Dine-In');
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'UPI' | 'Card'>('Cash');
  const [error, setError] = useState('');

  useEffect(() => {
    const user = getCurrentUser();
    if (!user) {
      onNavigate('login');
      return;
    }
    setCurrentUser(user);
    setCustomerName(user.name || '');

    const cart = getCart();
    if (cart.length === 0) {
      onNavigate('menu');
      return;
    }
    setCartItems(cart);
  }, []);

  const calculateTotal = () => {
    const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const tax = subtotal * 0.08;
    return subtotal + tax;
  };

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!customerName || !mobileNumber) {
      setError('Please fill in all required fields');
      return;
    }

    if (!/^\d{10}$/.test(mobileNumber)) {
      setError('Please enter a valid 10-digit mobile number');
      return;
    }

    const orderData = {
      customerName,
      mobileNumber,
      orderType,
      paymentMethod,
      items: cartItems,
      total: calculateTotal(),
      userEmail: currentUser.email
    };

    const order = createOrder(orderData);
    onOrderPlaced(order);
  };

  const total = calculateTotal();

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <h1 className="text-3xl font-bold mb-8">Checkout</h1>

        {error && (
          <div className="mb-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg">
            {error}
          </div>
        )}

        <form onSubmit={handlePlaceOrder}>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Customer Details */}
            <div className="space-y-6">
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-bold mb-4">Customer Details</h2>
                
                <div className="mb-4">
                  <label className="block text-gray-700 font-semibold mb-2">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                    placeholder="John Doe"
                    required
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-gray-700 font-semibold mb-2">
                    Mobile Number *
                  </label>
                  <input
                    type="tel"
                    value={mobileNumber}
                    onChange={(e) => setMobileNumber(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                    placeholder="1234567890"
                    required
                  />
                </div>
              </div>

              {/* Order Type */}
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-bold mb-4">Order Type</h2>
                <div className="grid grid-cols-2 gap-4">
                  <button
                    type="button"
                    onClick={() => setOrderType('Dine-In')}
                    className={`p-4 border-2 rounded-lg transition-colors ${
                      orderType === 'Dine-In'
                        ? 'border-red-600 bg-red-50'
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    <Store className="w-8 h-8 mx-auto mb-2 text-red-600" />
                    <p className="font-semibold">Dine-In</p>
                  </button>
                  <button
                    type="button"
                    onClick={() => setOrderType('Takeaway')}
                    className={`p-4 border-2 rounded-lg transition-colors ${
                      orderType === 'Takeaway'
                        ? 'border-red-600 bg-red-50'
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    <ShoppingBag className="w-8 h-8 mx-auto mb-2 text-red-600" />
                    <p className="font-semibold">Takeaway</p>
                  </button>
                </div>
              </div>

              {/* Payment Method */}
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-bold mb-4">Payment Method</h2>
                <div className="space-y-3">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('Cash')}
                    className={`w-full p-4 border-2 rounded-lg transition-colors flex items-center gap-3 ${
                      paymentMethod === 'Cash'
                        ? 'border-red-600 bg-red-50'
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    <DollarSign className="w-6 h-6 text-red-600" />
                    <span className="font-semibold">Cash</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('UPI')}
                    className={`w-full p-4 border-2 rounded-lg transition-colors flex items-center gap-3 ${
                      paymentMethod === 'UPI'
                        ? 'border-red-600 bg-red-50'
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    <Smartphone className="w-6 h-6 text-red-600" />
                    <span className="font-semibold">UPI</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('Card')}
                    className={`w-full p-4 border-2 rounded-lg transition-colors flex items-center gap-3 ${
                      paymentMethod === 'Card'
                        ? 'border-red-600 bg-red-50'
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    <CreditCard className="w-6 h-6 text-red-600" />
                    <span className="font-semibold">Card</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Order Summary */}
            <div>
              <div className="bg-white rounded-lg shadow-md p-6 sticky top-20">
                <h2 className="text-xl font-bold mb-4">Order Summary</h2>
                
                <div className="space-y-3 mb-4 pb-4 border-b max-h-64 overflow-y-auto">
                  {cartItems.map((item) => (
                    <div key={item.id} className="flex justify-between">
                      <div>
                        <p className="font-semibold">{item.name}</p>
                        <p className="text-sm text-gray-600">Qty: {item.quantity}</p>
                      </div>
                      <p className="font-semibold">₹{(item.price * item.quantity).toFixed(2)}</p>
                    </div>
                  ))}
                </div>

                <div className="space-y-2 mb-4 pb-4 border-b">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Subtotal</span>
                    <span className="font-semibold">
                      ₹{(total / 1.08).toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Tax (8%)</span>
                    <span className="font-semibold">
                      ₹{(total - total / 1.08).toFixed(2)}
                    </span>
                  </div>
                </div>

                <div className="flex justify-between mb-6 text-lg">
                  <span className="font-bold">Total</span>
                  <span className="font-bold text-red-600">₹{total.toFixed(2)}</span>
                </div>

                <button
                  type="submit"
                  className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold py-3 rounded-lg transition-colors"
                >
                  Place Order
                </button>

                <button
                  type="button"
                  onClick={() => onNavigate('cart')}
                  className="w-full mt-3 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold py-3 rounded-lg transition-colors"
                >
                  Back to Cart
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}