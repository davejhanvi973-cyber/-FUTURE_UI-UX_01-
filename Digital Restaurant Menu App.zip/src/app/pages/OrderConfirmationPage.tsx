import { CheckCircle, Home, UtensilsCrossed } from 'lucide-react';

interface OrderConfirmationPageProps {
  orderData: any;
  onNavigate: (page: string) => void;
}

export function OrderConfirmationPage({ orderData, onNavigate }: OrderConfirmationPageProps) {
  if (!orderData) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4">
        <div className="text-center">
          <p className="text-gray-600 mb-4">No order data available</p>
          <button
            onClick={() => onNavigate('menu')}
            className="px-6 py-3 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-lg transition-colors"
          >
            Back to Menu
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-2xl mx-auto px-4">
        <div className="bg-white rounded-lg shadow-lg p-8 text-center">
          {/* Success Icon */}
          <div className="flex justify-center mb-6">
            <CheckCircle className="w-24 h-24 text-green-500" />
          </div>

          {/* Success Message */}
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Order Confirmed!</h1>
          <p className="text-lg text-gray-600 mb-8">
            Thank you for your order. Your delicious meal is being prepared!
          </p>

          {/* Order Details */}
          <div className="bg-gray-50 rounded-lg p-6 mb-8 text-left">
            <h2 className="text-xl font-bold mb-4">Order Details</h2>
            
            <div className="space-y-3 mb-4 pb-4 border-b">
              <div className="flex justify-between">
                <span className="text-gray-600">Order ID:</span>
                <span className="font-semibold">#{orderData.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Customer Name:</span>
                <span className="font-semibold">{orderData.customerName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Mobile Number:</span>
                <span className="font-semibold">{orderData.mobileNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Order Type:</span>
                <span className="font-semibold">{orderData.orderType}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Payment Method:</span>
                <span className="font-semibold">{orderData.paymentMethod}</span>
              </div>
            </div>

            <div className="space-y-2 mb-4 pb-4 border-b">
              <h3 className="font-semibold mb-2">Items Ordered:</h3>
              {orderData.items.map((item: any) => (
                <div key={item.id} className="flex justify-between text-sm">
                  <span>{item.name} × {item.quantity}</span>
                  <span>₹{(item.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
            </div>

            <div className="flex justify-between text-lg">
              <span className="font-bold">Total Amount:</span>
              <span className="font-bold text-red-600">₹{orderData.total.toFixed(2)}</span>
            </div>
          </div>

          {/* Status Message */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-8">
            <p className="text-blue-800">
              {orderData.orderType === 'Dine-In'
                ? 'Please proceed to your table. Your order will be served shortly.'
                : 'Your order will be ready for pickup in 15-20 minutes.'}
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => onNavigate('menu')}
              className="flex items-center justify-center gap-2 px-6 py-3 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-lg transition-colors"
            >
              <UtensilsCrossed className="w-5 h-5" />
              Order Again
            </button>
            <button
              onClick={() => onNavigate('home')}
              className="flex items-center justify-center gap-2 px-6 py-3 bg-gray-200 hover:bg-gray-300 text-gray-700 font-semibold rounded-lg transition-colors"
            >
              <Home className="w-5 h-5" />
              Back to Home
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}