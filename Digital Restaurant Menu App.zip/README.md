# 🍽️ Digital Restaurant Menu and Ordering Interface

A modern, mobile-friendly restaurant ordering system built with React, TypeScript, and Tailwind CSS. All data is stored using browser LocalStorage - no backend required!

## 🎯 Features

### Customer Features
- **Home Page**: Beautiful landing page with restaurant branding and featured dishes
- **Authentication**: Login and signup functionality using LocalStorage
- **Menu Browsing**: Category-wise menu (Starters, Main Course, Desserts, Beverages)
- **Shopping Cart**: Add items, adjust quantities, and remove items
- **Checkout**: Select order type (Dine-In/Takeaway) and payment method (Cash/UPI/Card)
- **Order Confirmation**: Detailed order summary with order ID

### Admin Features
- **Admin Login**: Secure admin authentication
- **Menu Management**: Add new food items with images, prices, and descriptions
- **Order Management**: View all customer orders with details
- **Dashboard**: Tabbed interface for managing menu and orders

## 🔐 Demo Credentials

### Admin Access
- **Username**: admin
- **Password**: admin123

### Customer Access
- Create a new account using the signup page
- Or login with any registered user credentials

## 🚀 Getting Started

1. The application comes pre-loaded with sample menu items
2. Visit the home page to explore
3. Create a customer account to start ordering
4. Use admin credentials to access the admin panel

## 📱 Responsive Design

The application is fully responsive and works seamlessly on:
- Desktop computers
- Tablets
- Mobile phones

## 💾 Data Storage

All data is stored in browser LocalStorage:
- User accounts
- Menu items
- Shopping cart
- Order history

## 🎨 Design

- Modern restaurant theme with red, white, and dark colors
- Card-based layout for food items
- Smooth navigation and transitions
- Professional and clean UI

## 📄 Pages

1. **Home** - Landing page with call-to-action
2. **Login/Signup** - User authentication
3. **Menu** - Browse food items by category
4. **Cart** - Review and manage cart items
5. **Checkout** - Complete order with customer details
6. **Order Confirmation** - Success page with order details
7. **Admin Login** - Admin authentication
8. **Admin Dashboard** - Manage menu and view orders

## 🛠️ Technology Stack

- **Frontend**: React + TypeScript
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Data Storage**: Browser LocalStorage
- **Build Tool**: Vite

## 📝 Notes

- This is a client-side only application
- No backend or database required
- Perfect for demonstration and educational purposes
- Can be deployed on GitHub Pages or any static hosting service

---

Made with ❤️ for restaurant ordering
