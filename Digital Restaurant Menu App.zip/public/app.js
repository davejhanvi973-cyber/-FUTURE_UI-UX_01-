// Menu Data with Additional Vegetarian Options
const menuData = [
    // Starters
    {
        id: '1',
        name: 'Simple Salted Fries',
        category: 'Starters',
        price: 70,
        description: 'Crispy golden fries with a perfect salt seasoning',
        image: 'https://images.unsplash.com/photo-1717294978892-cef673e1d17b?w=400&h=300&fit=crop'
    },
    {
        id: '2',
        name: 'Peri Peri Fries',
        category: 'Starters',
        price: 90,
        description: 'Spicy peri peri seasoned fries',
        image: 'https://images.unsplash.com/photo-1723763246578-99e614b2a91b?w=400&h=300&fit=crop'
    },
    {
        id: '3',
        name: 'Peri Peri with Cheese',
        category: 'Starters',
        price: 100,
        description: 'Peri peri fries loaded with melted cheese',
        image: 'https://images.unsplash.com/photo-1639744210631-209fce3e256c?w=400&h=300&fit=crop'
    },
    {
        id: '4',
        name: 'Tandoori Fries',
        category: 'Starters',
        price: 100,
        description: 'Fries with tangy tandoori seasoning',
        image: 'https://images.unsplash.com/photo-1717294978892-cef673e1d17b?w=400&h=300&fit=crop'
    },
    {
        id: '5',
        name: 'Veg Supreme',
        category: 'Starters',
        price: 79,
        description: 'Cheese with dressing of onion, capsicum, tomato',
        image: 'https://images.unsplash.com/photo-1639744210631-209fce3e256c?w=400&h=300&fit=crop'
    },
    {
        id: '6',
        name: 'Peri Prime',
        category: 'Starters',
        price: 89,
        description: 'Peri peri plus cheese with selected veggies',
        image: 'https://images.unsplash.com/photo-1723763246578-99e614b2a91b?w=400&h=300&fit=crop'
    },
    {
        id: '7',
        name: 'Cheese Blast',
        category: 'Starters',
        price: 99,
        description: 'Cheese loaded on top, selected veggie with selected sauce',
        image: 'https://images.unsplash.com/photo-1639744210631-209fce3e256c?w=400&h=300&fit=crop'
    },
    {
        id: '60',
        name: 'Crispy Veg Samosa',
        category: 'Starters',
        price: 40,
        description: 'Classic Indian samosa with spiced potato filling (2 pcs)',
        image: 'https://images.unsplash.com/photo-1597058712635-3182d1eacc1e?w=400&h=300&fit=crop'
    },
    {
        id: '61',
        name: 'Veg Spring Rolls',
        category: 'Starters',
        price: 85,
        description: 'Crispy spring rolls with mixed vegetables (4 pcs)',
        image: 'https://images.unsplash.com/photo-1761315413785-0bf98364ceab?w=400&h=300&fit=crop'
    },
    {
        id: '62',
        name: 'Loaded Nachos',
        category: 'Starters',
        price: 120,
        description: 'Tortilla chips loaded with cheese, jalapenos, and salsa',
        image: 'https://images.unsplash.com/photo-1761315412554-ca6156afee65?w=400&h=300&fit=crop'
    },
    {
        id: '63',
        name: 'Garlic Bread with Cheese',
        category: 'Starters',
        price: 95,
        description: 'Toasted garlic bread topped with mozzarella cheese',
        image: 'https://images.unsplash.com/photo-1619531040576-f9416740661b?w=400&h=300&fit=crop'
    },
    {
        id: '64',
        name: 'Paneer Tikka',
        category: 'Starters',
        price: 140,
        description: 'Grilled paneer cubes marinated in Indian spices',
        image: 'https://images.unsplash.com/photo-1666001120694-3ebe8fd207be?w=400&h=300&fit=crop'
    },
    // Main Course - Pizzas
    {
        id: '8',
        name: 'Margherita Pizza (Large)',
        category: 'Main Course',
        price: 199,
        description: 'Classic mozzarella cheese pizza',
        image: 'https://images.unsplash.com/photo-1707896543317-da87bde75ff6?w=400&h=300&fit=crop'
    },
    {
        id: '9',
        name: 'Cheese Corn Pizza (Large)',
        category: 'Main Course',
        price: 219,
        description: 'Sweet corn with cheese',
        image: 'https://images.unsplash.com/photo-1595708684082-a173bb3a06c5?w=400&h=300&fit=crop'
    },
    {
        id: '10',
        name: 'Mexican Delight Pizza (Large)',
        category: 'Main Course',
        price: 229,
        description: 'Sweet corn, capsicum, olives, tomato',
        image: 'https://images.unsplash.com/photo-1617470702355-94a48c0b9729?w=400&h=300&fit=crop'
    },
    {
        id: '11',
        name: 'Bread Pizza Margherita',
        category: 'Main Course',
        price: 199,
        description: 'Mozzarella cheese on bread base',
        image: 'https://images.unsplash.com/photo-1707896543317-da87bde75ff6?w=400&h=300&fit=crop'
    },
    {
        id: '12',
        name: 'Bread Pizza Cheese Corn',
        category: 'Main Course',
        price: 219,
        description: 'Corn and cheese on bread base',
        image: 'https://images.unsplash.com/photo-1595708684082-a173bb3a06c5?w=400&h=300&fit=crop'
    },
    {
        id: '13',
        name: 'Bread Pizza Mexican Delight',
        category: 'Main Course',
        price: 229,
        description: 'Sweet corn, capsicum, olives, tomato on bread base',
        image: 'https://images.unsplash.com/photo-1617470702355-94a48c0b9729?w=400&h=300&fit=crop'
    },
    {
        id: '14',
        name: 'Chilli Spicy Bread Pizza',
        category: 'Main Course',
        price: 239,
        description: 'Onion, green chilli, capsicum, tomato',
        image: 'https://images.unsplash.com/photo-1595708684082-a173bb3a06c5?w=400&h=300&fit=crop'
    },
    {
        id: '15',
        name: 'Margherita Pizza (Regular)',
        category: 'Main Course',
        price: 149,
        description: 'Classic mozzarella cheese pizza',
        image: 'https://images.unsplash.com/photo-1707896543317-da87bde75ff6?w=400&h=300&fit=crop'
    },
    {
        id: '16',
        name: 'Cheese Corn Pizza (Regular)',
        category: 'Main Course',
        price: 169,
        description: 'Corn and cheese',
        image: 'https://images.unsplash.com/photo-1595708684082-a173bb3a06c5?w=400&h=300&fit=crop'
    },
    {
        id: '17',
        name: 'Vegie Special Pizza',
        category: 'Main Course',
        price: 179,
        description: 'Onion, capsicum, tomato',
        image: 'https://images.unsplash.com/photo-1617470702355-94a48c0b9729?w=400&h=300&fit=crop'
    },
    {
        id: '18',
        name: 'Chilli Garlic Pizza',
        category: 'Main Course',
        price: 189,
        description: 'Garlic and green chilli',
        image: 'https://images.unsplash.com/photo-1707896543317-da87bde75ff6?w=400&h=300&fit=crop'
    },
    // Pasta
    {
        id: '19',
        name: 'Red Sauce Pasta',
        category: 'Main Course',
        price: 100,
        description: 'Classic Italian red sauce pasta',
        image: 'https://images.unsplash.com/photo-1751151497799-8b4057a2638e?w=400&h=300&fit=crop'
    },
    {
        id: '20',
        name: 'Alfredo Pasta',
        category: 'Main Course',
        price: 110,
        description: 'Creamy white sauce pasta',
        image: 'https://images.unsplash.com/photo-1662478839788-7d2898ca66cf?w=400&h=300&fit=crop'
    },
    {
        id: '21',
        name: 'Pink Sauce Pasta',
        category: 'Main Course',
        price: 110,
        description: 'Creamy pink sauce pasta',
        image: 'https://images.unsplash.com/photo-1751151497799-8b4057a2638e?w=400&h=300&fit=crop'
    },
    {
        id: '22',
        name: 'Cheese Pasta',
        category: 'Main Course',
        price: 130,
        description: 'Pasta loaded with cheese',
        image: 'https://images.unsplash.com/photo-1662478839788-7d2898ca66cf?w=400&h=300&fit=crop'
    },
    // Burgers
    {
        id: '23',
        name: 'Aloo Tikki Burger',
        category: 'Main Course',
        price: 50,
        description: 'Classic potato patty burger',
        image: 'https://images.unsplash.com/photo-1522036664039-3c5756c2b459?w=400&h=300&fit=crop'
    },
    {
        id: '24',
        name: 'Cheese Aloo Tikki Burger',
        category: 'Main Course',
        price: 60,
        description: 'Aloo tikki burger with cheese',
        image: 'https://images.unsplash.com/photo-1522036664039-3c5756c2b459?w=400&h=300&fit=crop'
    },
    {
        id: '25',
        name: 'Veg Classic Burger',
        category: 'Main Course',
        price: 70,
        description: 'Classic vegetable burger',
        image: 'https://images.unsplash.com/photo-1522036664039-3c5756c2b459?w=400&h=300&fit=crop'
    },
    {
        id: '26',
        name: 'Paneer Tikka Burger',
        category: 'Main Course',
        price: 80,
        description: 'Grilled paneer tikka burger',
        image: 'https://images.unsplash.com/photo-1522036664039-3c5756c2b459?w=400&h=300&fit=crop'
    },
    {
        id: '27',
        name: 'Veg Peri Peri Burger',
        category: 'Main Course',
        price: 80,
        description: 'Spicy peri peri vegetable burger',
        image: 'https://images.unsplash.com/photo-1522036664039-3c5756c2b459?w=400&h=300&fit=crop'
    },
    // Sandwiches
    {
        id: '28',
        name: '3 Layer Paneer Spices',
        category: 'Main Course',
        price: 150,
        description: 'Paneer, rich spices, selected veg, crunch of veg tikki with tandoori sauce',
        image: 'https://images.unsplash.com/photo-1604908553403-8cc7756820d9?w=400&h=300&fit=crop'
    },
    {
        id: '29',
        name: 'Veg Cheese Grill',
        category: 'Main Course',
        price: 80,
        description: 'Grilled sandwich with vegetables and cheese',
        image: 'https://images.unsplash.com/photo-1604908553403-8cc7756820d9?w=400&h=300&fit=crop'
    },
    {
        id: '30',
        name: 'Chilli Cheese Grill',
        category: 'Main Course',
        price: 80,
        description: 'Spicy chilli and cheese grilled sandwich',
        image: 'https://images.unsplash.com/photo-1604908553403-8cc7756820d9?w=400&h=300&fit=crop'
    },
    {
        id: '31',
        name: 'Aloo Matar Grill',
        category: 'Main Course',
        price: 90,
        description: 'Potato and peas grilled sandwich',
        image: 'https://images.unsplash.com/photo-1604908553403-8cc7756820d9?w=400&h=300&fit=crop'
    },
    {
        id: '32',
        name: 'Paneer Tikka Grill',
        category: 'Main Course',
        price: 100,
        description: 'Paneer tikka grilled sandwich',
        image: 'https://images.unsplash.com/photo-1604908553403-8cc7756820d9?w=400&h=300&fit=crop'
    },
    {
        id: '33',
        name: 'Mexican Grill',
        category: 'Main Course',
        price: 110,
        description: 'Mexican style grilled sandwich',
        image: 'https://images.unsplash.com/photo-1604908553403-8cc7756820d9?w=400&h=300&fit=crop'
    },
    {
        id: '34',
        name: 'Veg Toofani Grill',
        category: 'Main Course',
        price: 120,
        description: 'Special spicy grilled sandwich',
        image: 'https://images.unsplash.com/photo-1604908553403-8cc7756820d9?w=400&h=300&fit=crop'
    },
    // Additional Main Course Items
    {
        id: '65',
        name: 'Paneer Butter Masala',
        category: 'Main Course',
        price: 180,
        description: 'Rich and creamy paneer curry with butter and tomato gravy',
        image: 'https://images.unsplash.com/photo-1666001120694-3ebe8fd207be?w=400&h=300&fit=crop'
    },
    {
        id: '66',
        name: 'Dal Makhani',
        category: 'Main Course',
        price: 150,
        description: 'Creamy black lentil curry slow-cooked with spices',
        image: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=400&h=300&fit=crop'
    },
    {
        id: '67',
        name: 'Veg Biryani',
        category: 'Main Course',
        price: 160,
        description: 'Fragrant basmati rice with mixed vegetables and spices',
        image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=400&h=300&fit=crop'
    },
    {
        id: '68',
        name: 'Chole Bhature',
        category: 'Main Course',
        price: 140,
        description: 'Spicy chickpea curry with fluffy fried bread',
        image: 'https://images.unsplash.com/photo-1626132647523-66f5bf380027?w=400&h=300&fit=crop'
    },
    // Desserts
    {
        id: '35',
        name: 'Sizzling Star',
        category: 'Desserts',
        price: 99,
        description: 'Chocolate brownie served with vanilla ice cream',
        image: 'https://images.unsplash.com/photo-1570145820259-b5b80c5c8bd6?w=400&h=300&fit=crop'
    },
    {
        id: '36',
        name: 'Sizzling Chocobar',
        category: 'Desserts',
        price: 119,
        description: 'Chocolate brownie served with choco bar',
        image: 'https://images.unsplash.com/photo-1570145820259-b5b80c5c8bd6?w=400&h=300&fit=crop'
    },
    {
        id: '37',
        name: 'Oreo Crunch',
        category: 'Desserts',
        price: 129,
        description: 'Chocolate brownie loaded with Oreo cookies and vanilla ice cream',
        image: 'https://images.unsplash.com/photo-1702827402754-b1aef85e052a?w=400&h=300&fit=crop'
    },
    {
        id: '38',
        name: 'Nutella Thunder',
        category: 'Desserts',
        price: 179,
        description: 'Chocolate brownie loaded with Nutella and vanilla ice cream and choco toppings',
        image: 'https://images.unsplash.com/photo-1702827402754-b1aef85e052a?w=400&h=300&fit=crop'
    },
    {
        id: '39',
        name: 'Sizzling Boat',
        category: 'Desserts',
        price: 199,
        description: 'Chocolate brownie loaded with triple chocolate and choco balls and vanilla ice cream',
        image: 'https://images.unsplash.com/photo-1702827402754-b1aef85e052a?w=400&h=300&fit=crop'
    },
    {
        id: '40',
        name: 'Mud Brownie',
        category: 'Desserts',
        price: 99,
        description: 'Classic chocolate mud brownie',
        image: 'https://images.unsplash.com/photo-1570145820259-b5b80c5c8bd6?w=400&h=300&fit=crop'
    },
    {
        id: '41',
        name: 'Mud Brownie with Vanilla Ice Cream',
        category: 'Desserts',
        price: 119,
        description: 'Mud brownie served with vanilla ice cream',
        image: 'https://images.unsplash.com/photo-1702827402754-b1aef85e052a?w=400&h=300&fit=crop'
    },
    {
        id: '42',
        name: 'White Chocolate Fudge Brownie',
        category: 'Desserts',
        price: 149,
        description: 'Rich white chocolate fudge brownie',
        image: 'https://images.unsplash.com/photo-1570145820259-b5b80c5c8bd6?w=400&h=300&fit=crop'
    },
    {
        id: '43',
        name: 'Dark Chocolate Fudge Brownie',
        category: 'Desserts',
        price: 149,
        description: 'Rich dark chocolate fudge brownie',
        image: 'https://images.unsplash.com/photo-1570145820259-b5b80c5c8bd6?w=400&h=300&fit=crop'
    },
    {
        id: '44',
        name: 'Triple Chocolate Fudge Brownie',
        category: 'Desserts',
        price: 149,
        description: 'Triple chocolate loaded fudge brownie',
        image: 'https://images.unsplash.com/photo-1570145820259-b5b80c5c8bd6?w=400&h=300&fit=crop'
    },
    // Beverages
    {
        id: '45',
        name: 'Chocolate Milkshake',
        category: 'Beverages',
        price: 80,
        description: 'Creamy chocolate milkshake (350 ML)',
        image: 'https://images.unsplash.com/photo-1629603401856-82dad13ca4d2?w=400&h=300&fit=crop'
    },
    {
        id: '46',
        name: 'Mango Milkshake',
        category: 'Beverages',
        price: 80,
        description: 'Fresh mango milkshake (350 ML)',
        image: 'https://images.unsplash.com/photo-1629603401856-82dad13ca4d2?w=400&h=300&fit=crop'
    },
    {
        id: '47',
        name: 'Strawberry Milkshake',
        category: 'Beverages',
        price: 80,
        description: 'Fresh strawberry milkshake (350 ML)',
        image: 'https://images.unsplash.com/photo-1629603401856-82dad13ca4d2?w=400&h=300&fit=crop'
    },
    {
        id: '48',
        name: 'Pineapple Milkshake',
        category: 'Beverages',
        price: 80,
        description: 'Tropical pineapple milkshake (350 ML)',
        image: 'https://images.unsplash.com/photo-1629603401856-82dad13ca4d2?w=400&h=300&fit=crop'
    },
    {
        id: '49',
        name: 'Watermelon Milkshake',
        category: 'Beverages',
        price: 90,
        description: 'Refreshing watermelon milkshake (350 ML)',
        image: 'https://images.unsplash.com/photo-1629603401856-82dad13ca4d2?w=400&h=300&fit=crop'
    },
    {
        id: '50',
        name: 'Saffron Milkshake',
        category: 'Beverages',
        price: 100,
        description: 'Premium saffron milkshake (350 ML)',
        image: 'https://images.unsplash.com/photo-1629603401856-82dad13ca4d2?w=400&h=300&fit=crop'
    },
    {
        id: '51',
        name: 'Hot Coffee',
        category: 'Beverages',
        price: 50,
        description: 'Fresh hot coffee (200 ML)',
        image: 'https://images.unsplash.com/photo-1631305588811-3f8c5a222317?w=400&h=300&fit=crop'
    },
    {
        id: '52',
        name: 'Hot Chocolate',
        category: 'Beverages',
        price: 50,
        description: 'Rich hot chocolate (200 ML)',
        image: 'https://images.unsplash.com/photo-1631305588811-3f8c5a222317?w=400&h=300&fit=crop'
    },
    {
        id: '53',
        name: 'Mint Mojito',
        category: 'Beverages',
        price: 70,
        description: 'Refreshing mint mojito',
        image: 'https://images.unsplash.com/photo-1724155331840-263a0454d8bb?w=400&h=300&fit=crop'
    },
    {
        id: '54',
        name: 'Blue Curacao Mojito',
        category: 'Beverages',
        price: 70,
        description: 'Vibrant blue curacao mojito',
        image: 'https://images.unsplash.com/photo-1724155331840-263a0454d8bb?w=400&h=300&fit=crop'
    },
    {
        id: '55',
        name: 'Strawberry Mojito',
        category: 'Beverages',
        price: 80,
        description: 'Fresh strawberry mojito',
        image: 'https://images.unsplash.com/photo-1724155331840-263a0454d8bb?w=400&h=300&fit=crop'
    },
    {
        id: '56',
        name: 'Watermelon Mojito',
        category: 'Beverages',
        price: 80,
        description: 'Refreshing watermelon mojito',
        image: 'https://images.unsplash.com/photo-1724155331840-263a0454d8bb?w=400&h=300&fit=crop'
    },
    {
        id: '57',
        name: 'Kiwi Mojito',
        category: 'Beverages',
        price: 80,
        description: 'Tangy kiwi mojito',
        image: 'https://images.unsplash.com/photo-1724155331840-263a0454d8bb?w=400&h=300&fit=crop'
    },
    {
        id: '58',
        name: 'Chilli Guava Mojito',
        category: 'Beverages',
        price: 90,
        description: 'Spicy chilli guava mojito',
        image: 'https://images.unsplash.com/photo-1724155331840-263a0454d8bb?w=400&h=300&fit=crop'
    },
    {
        id: '59',
        name: 'Spicy Mango Mojito',
        category: 'Beverages',
        price: 90,
        description: 'Tangy spicy mango mojito',
        image: 'https://images.unsplash.com/photo-1724155331840-263a0454d8bb?w=400&h=300&fit=crop'
    }
];

// Initialize LocalStorage
function initializeLocalStorage() {
    if (!localStorage.getItem('menuItems')) {
        localStorage.setItem('menuItems', JSON.stringify(menuData));
    }
    if (!localStorage.getItem('users')) {
        localStorage.setItem('users', JSON.stringify([]));
    }
    if (!localStorage.getItem('orders')) {
        localStorage.setItem('orders', JSON.stringify([]));
    }
    if (!localStorage.getItem('cart')) {
        localStorage.setItem('cart', JSON.stringify([]));
    }
}

// Page Navigation
function showPage(pageName) {
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => page.classList.remove('active'));
    
    const targetPage = document.getElementById(`${pageName}Page`);
    if (targetPage) {
        targetPage.classList.add('active');
        
        // Update content based on page
        if (pageName === 'menu') {
            loadMenuItems();
        } else if (pageName === 'cart') {
            loadCartPage();
        } else if (pageName === 'checkout') {
            loadCheckoutPage();
        } else if (pageName === 'admin-dashboard') {
            if (isAdminLoggedIn()) {
                loadAdminDashboard();
            } else {
                showPage('admin-login');
            }
        }
        
        updateAuthLink();
    }
}

// Authentication Functions
function handleLogin(event) {
    event.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    const users = JSON.parse(localStorage.getItem('users'));
    const user = users.find(u => u.email === email && u.password === password);
    
    if (user) {
        const { password, ...userWithoutPassword } = user;
        localStorage.setItem('currentUser', JSON.stringify(userWithoutPassword));
        showToast('Login successful!', 'success');
        showPage('menu');
        updateAuthLink();
    } else {
        showToast('Invalid email or password', 'error');
    }
}

function handleSignup(event) {
    event.preventDefault();
    const name = document.getElementById('signupName').value;
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    
    const users = JSON.parse(localStorage.getItem('users'));
    
    if (users.find(u => u.email === email)) {
        showToast('Email already registered', 'error');
        return;
    }
    
    const newUser = {
        id: Date.now().toString(),
        name,
        email,
        password,
        createdAt: new Date().toISOString()
    };
    
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    showToast('Registration successful! Please login.', 'success');
    showPage('login');
}

function handleAuthAction() {
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
        localStorage.removeItem('currentUser');
        showToast('Logged out successfully', 'success');
        showPage('home');
        updateAuthLink();
    } else {
        showPage('login');
    }
}

function updateAuthLink() {
    const authLink = document.getElementById('authLink');
    const currentUser = localStorage.getItem('currentUser');
    authLink.textContent = currentUser ? 'Logout' : 'Login';
}

// Admin Functions
function handleAdminLogin(event) {
    event.preventDefault();
    const username = document.getElementById('adminUsername').value;
    const password = document.getElementById('adminPassword').value;
    
    if (username === 'admin' && password === 'admin123') {
        localStorage.setItem('currentAdmin', JSON.stringify({ username: 'admin' }));
        showToast('Admin login successful!', 'success');
        showPage('admin-dashboard');
    } else {
        showToast('Invalid admin credentials', 'error');
    }
}

function handleAdminLogout() {
    localStorage.removeItem('currentAdmin');
    showToast('Admin logged out', 'success');
    showPage('home');
}

function isAdminLoggedIn() {
    return localStorage.getItem('currentAdmin') !== null;
}

function showAdminTab(tabName) {
    const tabs = document.querySelectorAll('.admin-tab');
    const buttons = document.querySelectorAll('.tab-btn');
    
    tabs.forEach(tab => tab.classList.remove('active'));
    buttons.forEach(btn => btn.classList.remove('active'));
    
    document.getElementById(`admin${tabName.charAt(0).toUpperCase() + tabName.slice(1)}Tab`).classList.add('active');
    event.target.classList.add('active');
    
    if (tabName === 'menu') {
        loadAdminMenuItems();
    } else if (tabName === 'orders') {
        loadAdminOrders();
    }
}

function loadAdminDashboard() {
    loadAdminMenuItems();
    loadAdminOrders();
}

function loadAdminMenuItems() {
    const menuItems = JSON.parse(localStorage.getItem('menuItems'));
    const container = document.getElementById('adminMenuItems');
    
    container.innerHTML = menuItems.map(item => `
        <div class="admin-menu-card">
            <img src="${item.image}" alt="${item.name}">
            <h3>${item.name}</h3>
            <p class="category">${item.category}</p>
            <p class="price">₹${item.price.toFixed(2)}</p>
            <button class="btn btn-danger btn-block" onclick="deleteMenuItem('${item.id}')">Delete</button>
        </div>
    `).join('');
}

function handleAddItem(event) {
    event.preventDefault();
    
    const menuItems = JSON.parse(localStorage.getItem('menuItems'));
    const newItem = {
        id: Date.now().toString(),
        name: document.getElementById('itemName').value,
        category: document.getElementById('itemCategory').value,
        price: parseInt(document.getElementById('itemPrice').value),
        description: document.getElementById('itemDescription').value,
        image: document.getElementById('itemImage').value
    };
    
    menuItems.push(newItem);
    localStorage.setItem('menuItems', JSON.stringify(menuItems));
    
    showToast('Item added successfully!', 'success');
    document.getElementById('addItemForm').reset();
    loadAdminMenuItems();
}

function deleteMenuItem(itemId) {
    if (confirm('Are you sure you want to delete this item?')) {
        const menuItems = JSON.parse(localStorage.getItem('menuItems'));
        const updatedItems = menuItems.filter(item => item.id !== itemId);
        localStorage.setItem('menuItems', JSON.stringify(updatedItems));
        showToast('Item deleted successfully', 'success');
        loadAdminMenuItems();
    }
}

function loadAdminOrders() {
    const orders = JSON.parse(localStorage.getItem('orders'));
    const container = document.getElementById('adminOrders');
    
    if (orders.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: #6b7280;">No orders yet</p>';
        return;
    }
    
    container.innerHTML = orders.reverse().map(order => `
        <div class="admin-order-card">
            <div class="order-header">
                <span class="order-id">Order #${order.id}</span>
                <span class="order-status">${order.status}</span>
            </div>
            <p><strong>Customer:</strong> ${order.customerName}</p>
            <p><strong>Phone:</strong> ${order.phone}</p>
            <p><strong>Address:</strong> ${order.address}</p>
            <p><strong>Payment:</strong> ${order.paymentMethod === 'cod' ? 'Cash on Delivery' : 'Online Payment'}</p>
            <div class="order-items">
                ${order.items.map(item => `
                    <div class="order-item-row">
                        <span>${item.name} × ${item.quantity}</span>
                        <span>₹${(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                `).join('')}
            </div>
            <div class="order-total">
                <span>Total</span>
                <span>₹${order.total.toFixed(2)}</span>
            </div>
        </div>
    `).join('');
}

// Menu Functions
function loadMenuItems(category = 'All') {
    const menuItems = JSON.parse(localStorage.getItem('menuItems'));
    const filteredItems = category === 'All' 
        ? menuItems 
        : menuItems.filter(item => item.category === category);
    
    const menuGrid = document.getElementById('menuGrid');
    menuGrid.innerHTML = filteredItems.map(item => `
        <div class="menu-card">
            <img src="${item.image}" alt="${item.name}" class="menu-card-image">
            <div class="menu-card-content">
                <div class="menu-card-category">${item.category}</div>
                <h3 class="menu-card-name">${item.name}</h3>
                <p class="menu-card-description">${item.description}</p>
                <div class="menu-card-footer">
                    <span class="menu-card-price">₹${item.price.toFixed(2)}</span>
                    <button class="add-to-cart-btn" onclick="addToCart('${item.id}')">Add to Cart</button>
                </div>
            </div>
        </div>
    `).join('');
}

function filterCategory(category) {
    const buttons = document.querySelectorAll('.filter-btn');
    buttons.forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    loadMenuItems(category);
}

// Cart Functions
function addToCart(itemId) {
    const menuItems = JSON.parse(localStorage.getItem('menuItems'));
    const item = menuItems.find(i => i.id === itemId);
    
    if (!item) return;
    
    const cart = JSON.parse(localStorage.getItem('cart'));
    const existingItem = cart.find(i => i.id === itemId);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({ ...item, quantity: 1 });
    }
    
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartBadge();
    showToast('Added to cart!', 'success');
}

function updateCartBadge() {
    const cart = JSON.parse(localStorage.getItem('cart'));
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    document.getElementById('cartBadge').textContent = totalItems;
}

function loadCartPage() {
    const cart = JSON.parse(localStorage.getItem('cart'));
    const cartItems = document.getElementById('cartItems');
    
    if (cart.length === 0) {
        cartItems.innerHTML = `
            <div class="empty-cart">
                <div class="empty-cart-icon">🛒</div>
                <h2>Your cart is empty</h2>
                <p>Add some delicious items to get started!</p>
                <button class="btn btn-primary" onclick="showPage('menu')">Browse Menu</button>
            </div>
        `;
        document.querySelector('.cart-summary').style.display = 'none';
        return;
    }
    
    document.querySelector('.cart-summary').style.display = 'block';
    
    cartItems.innerHTML = cart.map(item => `
        <div class="cart-item">
            <img src="${item.image}" alt="${item.name}" class="cart-item-image">
            <div class="cart-item-details">
                <h3 class="cart-item-name">${item.name}</h3>
                <p class="cart-item-category">${item.category}</p>
                <p class="cart-item-price">₹${item.price.toFixed(2)}</p>
                <div class="cart-item-controls">
                    <button class="quantity-btn" onclick="updateQuantity('${item.id}', ${item.quantity - 1})">-</button>
                    <span class="quantity-display">${item.quantity}</span>
                    <button class="quantity-btn" onclick="updateQuantity('${item.id}', ${item.quantity + 1})">+</button>
                    <button class="remove-btn" onclick="removeFromCart('${item.id}')">Remove</button>
                </div>
            </div>
        </div>
    `).join('');
    
    updateCartSummary();
}

function updateQuantity(itemId, newQuantity) {
    if (newQuantity < 1) {
        removeFromCart(itemId);
        return;
    }
    
    const cart = JSON.parse(localStorage.getItem('cart'));
    const item = cart.find(i => i.id === itemId);
    
    if (item) {
        item.quantity = newQuantity;
        localStorage.setItem('cart', JSON.stringify(cart));
        loadCartPage();
        updateCartBadge();
    }
}

function removeFromCart(itemId) {
    const cart = JSON.parse(localStorage.getItem('cart'));
    const updatedCart = cart.filter(i => i.id !== itemId);
    localStorage.setItem('cart', JSON.stringify(updatedCart));
    loadCartPage();
    updateCartBadge();
    showToast('Item removed from cart', 'success');
}

function updateCartSummary() {
    const cart = JSON.parse(localStorage.getItem('cart'));
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const tax = subtotal * 0.08;
    const total = subtotal + tax;
    
    document.getElementById('cartSubtotal').textContent = `₹${subtotal.toFixed(2)}`;
    document.getElementById('cartTax').textContent = `₹${tax.toFixed(2)}`;
    document.getElementById('cartTotal').textContent = `₹${total.toFixed(2)}`;
}

function proceedToCheckout() {
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) {
        showToast('Please login to continue', 'error');
        showPage('login');
        return;
    }
    showPage('checkout');
}

// Checkout Functions
function loadCheckoutPage() {
    const cart = JSON.parse(localStorage.getItem('cart'));
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    
    if (currentUser) {
        document.getElementById('checkoutName').value = currentUser.name;
    }
    
    const checkoutItems = document.getElementById('checkoutItems');
    checkoutItems.innerHTML = cart.map(item => `
        <div class="checkout-item">
            <span>${item.name} × ${item.quantity}</span>
            <span>₹${(item.price * item.quantity).toFixed(2)}</span>
        </div>
    `).join('');
    
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const tax = subtotal * 0.08;
    const total = subtotal + tax;
    
    document.getElementById('checkoutSubtotal').textContent = `₹${subtotal.toFixed(2)}`;
    document.getElementById('checkoutTax').textContent = `₹${tax.toFixed(2)}`;
    document.getElementById('checkoutTotal').textContent = `₹${total.toFixed(2)}`;
}

function handleCheckout(event) {
    event.preventDefault();
    
    const cart = JSON.parse(localStorage.getItem('cart'));
    const orders = JSON.parse(localStorage.getItem('orders'));
    
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const tax = subtotal * 0.08;
    const total = subtotal + tax;
    
    const order = {
        id: Date.now().toString(),
        customerName: document.getElementById('checkoutName').value,
        phone: document.getElementById('checkoutPhone').value,
        address: document.getElementById('checkoutAddress').value,
        paymentMethod: document.querySelector('input[name="payment"]:checked').value,
        items: cart,
        subtotal,
        tax,
        total,
        status: 'Pending',
        createdAt: new Date().toISOString()
    };
    
    orders.push(order);
    localStorage.setItem('orders', JSON.stringify(orders));
    localStorage.setItem('cart', JSON.stringify([]));
    localStorage.setItem('lastOrder', JSON.stringify(order));
    
    updateCartBadge();
    showOrderConfirmation(order);
}

function showOrderConfirmation(order) {
    const orderDetails = document.getElementById('orderDetails');
    orderDetails.innerHTML = `
        <h3>Order ID: #${order.id}</h3>
        <div style="margin-top: 1rem;">
            <p><strong>Delivery to:</strong> ${order.customerName}</p>
            <p><strong>Phone:</strong> ${order.phone}</p>
            <p><strong>Address:</strong> ${order.address}</p>
        </div>
        <div style="margin-top: 1.5rem;">
            <h4 style="margin-bottom: 0.5rem;">Order Items:</h4>
            ${order.items.map(item => `
                <div class="order-item">
                    <span>${item.name} × ${item.quantity}</span>
                    <span>₹${(item.price * item.quantity).toFixed(2)}</span>
                </div>
            `).join('')}
        </div>
        <div style="margin-top: 1rem; padding-top: 1rem; border-top: 2px solid #e5e7eb;">
            <div class="order-item" style="font-weight: bold; font-size: 1.125rem;">
                <span>Total Amount</span>
                <span style="color: var(--primary-color);">₹${order.total.toFixed(2)}</span>
            </div>
        </div>
    `;
    showPage('confirmation');
}

// Toast Notification
function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast ${type} show`;
    
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

// Initialize App
document.addEventListener('DOMContentLoaded', () => {
    initializeLocalStorage();
    updateCartBadge();
    updateAuthLink();
    loadMenuItems();
});
